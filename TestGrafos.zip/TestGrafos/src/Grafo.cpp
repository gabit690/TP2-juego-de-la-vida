/*
 * Grafo.cpp
 *
 *  Created on: 29 nov. 2018
 *      Author: gabit
 */

#include "Grafo.h"

Grafo::Grafo() {
	this->vertices = new ListaSimple<Vertice*>();
	this->aristas = new ListaSimple<Arista*>();
}

void Grafo::agregarUnVertice(std::string nombre){
	Vertice* nuevoVertice = new Vertice(nombre);
	this->vertices->insertar(nuevoVertice, this->vertices->contarElementos()+1);
}

void Grafo::agregarUnaArista(std::string origen, std::string destino){
	Arista* nuevaArista = new Arista();
	nuevaArista->setOrigen(origen);
	nuevaArista->setDestino(destino);
	this->aristas->insertar(nuevaArista, this->aristas->contarElementos()+1);
}

ListaSimple<Vertice*>* Grafo::obtenerVertices(){
	return this->vertices;
}

ListaSimple<Arista*>* Grafo::obtenerAristas(){
	return this->aristas;
}

ListaSimple<std::string> Grafo::obtenerElCaminoMinimo(std::string origen, std::string destino){

}

void Grafo::etiquetarVertices(){

}

void Grafo::liberarVertices(){
	while(!this->vertices->estaVacia()){
		Vertice* removido;
		removido = this->vertices->remover(1);
		delete removido;
	}
}

void Grafo::liberarAristas(){
	while(!this->aristas->estaVacia()){
		Arista* removido;
		removido = this->aristas->remover(1);
		delete removido;
	}
}

Grafo::~Grafo(){

}
