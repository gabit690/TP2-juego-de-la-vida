/*
 * Grafo.h
 *
 *  Created on: 29 nov. 2018
 *      Author: gabit
 */

#ifndef GRAFO_H_
#define GRAFO_H_

#include "Vertice.h"
#include "Arista.h"

class Grafo {

private:
	ListaSimple<Vertice*>* vertices;
	ListaSimple<Arista*>* aristas;

public:

	/* Pre: .
	 * Post: crea un grafo sin vertices ni aristas.
	 */
	Grafo();

	/* Pre: -.
	 * Post: crea un vertice con el nombre indicado y lo agrega a los vertices existentes en el grafo.
	 */
	void agregarUnVertice(std::string nombre);

	/* Pre: -.
	 * Post: crea una arista que va del origen hasta el destino indicado y la agrega a las aristas existentes en el grafo.
	 */
	void agregarUnaArista(std::string origen, std::string destino);

	/* Pre: -.
	 * Post: devuelve los vertices del grafo.
	 */
	ListaSimple<Vertice*>* obtenerVertices();

	/* Pre: -.
	 * Post: devuelve las aristas del grafo.
	 */
	ListaSimple<Arista*>* obtenerAristas();

	/* Pre:
	 * Post:
	 */
	ListaSimple<std::string> obtenerElCaminoMinimo(std::string origen, std::string destino);

	/* Pre: -.
	 * Post: etiqueta todos los vertices del grafo.
	 */
	void etiquetarVertices();

	/* Pre: -.
	 * Post: vacia la lista de vertices liberando la memoria pedida para cada uno de ellos.
	 */
	void liberarVertices();

	/* Pre: -.
	 * Post: vacia la lista de aristas liberando la memoria pedida para cada una de ellas.
	 */
	void liberarAristas();

	/* Pre: -;
	 * Post: libera los recursos de memoria pedidos.
	 */
	~Grafo();
};

#endif /* GRAFO_H_ */
