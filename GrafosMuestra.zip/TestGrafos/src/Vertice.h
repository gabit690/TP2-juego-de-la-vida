/*
 * Vertice.h
 *
 *  Created on: 29 nov. 2018
 *      Author: gabit
 */

#ifndef VERTICE_H_
#define VERTICE_H_

#include "ListaSimple.h"
#include "Etiqueta.h"
#include "Arista.h"

class Vertice {

private:
	std::string identificador;
	ListaSimple<Etiqueta*>* etiquetas;
	ListaSimple<Arista*>* aristasAdyacentes;

public:
	/* Pre: -.
	 * Post: crea un vertice identificado por 'nombre' con las listas de etiquetas y aristas adyacentes vacias.
	 */
	Vertice(std::string nombre);

	/* Pre: 'unaEtiqueta' esta inicializada.
	 * Post: compara las etiquetas del vertice con 'unaEtiqueta' para agregarla en el caso que
	 * su valor acumulado sea igual a las demas o que quede como la unica etiqueta si es mejor que el resto.
	 */
	void compararEtiqueta(Etiqueta* unaEtiqueta);

	/* Pre: 'unaArista' esta inicialiazda y tiene como origen al identificador del vertice.
	 * Post: agrega una arista que es adyacente al vertice.
	 */
	void agregarAristaAdyacente(Arista* unaArista);

	/* Pre: -.
	 * Post: devuelve la lista de etiquetas.
	 */
	ListaSimple<Etiqueta*>* getEtiquetas();

	/* Pre: -.
	 * Post: devuelve la lista de aristas adyacentes.
	 */
	ListaSimple<Arista*>* getAdyacentes();

	/* Pre: -.
	 * Post: devuelve el identificador del vertice.
	 */
	std::string getIdentificador();

	/* Pre: -.
	 * Post: libera los recursos de memoria pedidos.
	 */
	~Vertice();

private:
	/* Pre: -.
	 * Post: vacia la lista de etiquetas liberando la memoria pedida para cada una de ellas.
	 */
	void liberarEtiquetas();
};

#endif /* VERTICE_H_ */
