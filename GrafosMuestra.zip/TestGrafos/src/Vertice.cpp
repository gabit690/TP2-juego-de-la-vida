/*
 * Vertice.cpp
 *
 *  Created on: 29 nov. 2018
 *      Author: gabit
 */

#include "Vertice.h"
using namespace std;

Vertice::Vertice(std::string nombre){
	this->identificador = nombre;
	this->etiquetas = new ListaSimple<Etiqueta*>();
	this->aristasAdyacentes = new ListaSimple<Arista*>();
}

void Vertice::compararEtiqueta(Etiqueta* unaEtiqueta){
	unsigned int acumulacionDeEtiquetaNueva = unaEtiqueta->getAcumulacion();
	unsigned int acumulacionDeEtiquetaListada = this->etiquetas->obtenerElemento(1)->getAcumulacion();
	bool esIgual = (acumulacionDeEtiquetaListada == acumulacionDeEtiquetaNueva );
	bool esMayor = (acumulacionDeEtiquetaListada < acumulacionDeEtiquetaNueva );

	if(esIgual){
		this->etiquetas->insertar(unaEtiqueta, this->etiquetas->contarElementos()+1);
	}
	else{
		if(esMayor){
			this->liberarEtiquetas();
			this->etiquetas->insertar(unaEtiqueta, 1);
		}
	}
}

void Vertice::agregarAristaAdyacente(Arista* unaArista){
	this->aristasAdyacentes->insertar(unaArista, this->aristasAdyacentes->contarElementos()+1);
}

ListaSimple<Etiqueta*>* Vertice::getEtiquetas(){
	return this->etiquetas;
}

ListaSimple<Arista*>* Vertice::getAdyacentes(){
	return this->aristasAdyacentes;
}

void Vertice::liberarEtiquetas(){
	while(!this->etiquetas->estaVacia()){
		Etiqueta* removido;
		removido = this->etiquetas->remover(1);
		delete removido;
	}
}

string Vertice::getIdentificador(){
	return this->identificador;
}

Vertice::~Vertice(){
	this->liberarEtiquetas();
	delete this->etiquetas;
	delete this->aristasAdyacentes;
}
