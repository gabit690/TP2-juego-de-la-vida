/*
 * main.cpp
 *
 *  Created on: 29 nov. 2018
 *      Author: gabit
 */

#include "Grafo.h"
#include <iostream>

int main (){
	Grafo* elGrafo = new Grafo();

	elGrafo->agregarUnVertice("Tablero1");
	elGrafo->agregarUnVertice("Tablero2");
	elGrafo->agregarUnVertice("Tablero3");
	elGrafo->agregarUnVertice("Tablero4");
	elGrafo->agregarUnVertice("Tablero5");
	elGrafo->agregarUnVertice("Tablero6");

	elGrafo->agregarUnaArista("Tablero1", "Tablero2");
	elGrafo->agregarUnaArista("Tablero4", "Tablero1");
	elGrafo->agregarUnaArista("Tablero4", "Tablero2");
	elGrafo->agregarUnaArista("Tablero2", "Tablero4");
	elGrafo->agregarUnaArista("Tablero2", "Tablero6");
	elGrafo->agregarUnaArista("Tablero3", "Tablero6");
	elGrafo->agregarUnaArista("Tablero6", "Tablero3");

	ListaSimple<Arista*>* aristas;
	aristas = elGrafo->obtenerAristas();

	Arista* unaArista;
	unaArista = aristas->obtenerElemento(2);

	std::cout << "Origen: " << unaArista->getOrigen() << std::endl;
	std::cout << "Destino: " << unaArista->getDestino() << std::endl;
	std::cout << "Peso: " << unaArista->getPeso() << std::endl << std::endl;

	unaArista->aumentarUnidadApeso();
	unaArista->aumentarUnidadApeso();
	unaArista->aumentarUnidadApeso();

	Arista* laMismaArista;

	laMismaArista = aristas->obtenerElemento(2);

	std::cout << "Post modificacion" << std::endl;
	std::cout << "Origen: " << laMismaArista->getOrigen() << std::endl;
	std::cout << "Destino: " << laMismaArista->getDestino() << std::endl;
	std::cout << "Peso: " << laMismaArista->getPeso() << std::endl;

	delete elGrafo;
	return 0;
}


