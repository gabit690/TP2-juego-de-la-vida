/*
 * main.cpp
 *
 *  Created on: 9 oct. 2018
 *      Author: gabit
 */

#include "EasyBMP.h"
using namespace std;

void operacionesBasicas();

void modificacionTablaDeColores();

void copiaPixelAPixel();


void colorPleno(RGBApixel unColor){
	// no se realizan modificaciones.
}

RGBApixel colorAlto(RGBApixel unColor){
	RGBApixel elColor;
	ebmpBYTE colorMaximo = 255;
	elColor.Red = (unColor.Red+(1*((colorMaximo-unColor.Red)/4)));
	elColor.Green = (unColor.Green+(1*((colorMaximo-unColor.Green)/4)));
	elColor.Blue = (unColor.Blue+(1*((colorMaximo-unColor.Blue)/4)));
	return elColor;
}

RGBApixel colorMedio(RGBApixel unColor){
	RGBApixel elColor;
	ebmpBYTE colorMaximo = 255;
	elColor.Red = (unColor.Red+(2*((colorMaximo-unColor.Red)/4)));
	elColor.Green = (unColor.Green+(2*((colorMaximo-unColor.Green)/4)));
	elColor.Blue = (unColor.Blue+(2*((colorMaximo-unColor.Blue)/4)));
	return elColor;
}

RGBApixel colorBajo(RGBApixel unColor){
	RGBApixel elColor;
	ebmpBYTE colorMaximo = 255;
	elColor.Red = (unColor.Red+(3*((colorMaximo-unColor.Red)/4)));
	elColor.Green = (unColor.Green+(3*((colorMaximo-unColor.Green)/4)));
	elColor.Blue = (unColor.Blue+(3*((colorMaximo-unColor.Blue)/4)));
	return elColor;
}

RGBApixel colorVacio(){
	RGBApixel elColor;
	elColor.Red = 255;
	elColor.Green = 255;
	elColor.Blue = 255;
	return elColor;
}

int main( ){

	BMP parcela;
	parcela.SetBitDepth(24);
	parcela.SetSize(80,80);
	for(int x = 0; x<80; x++){
		for(int y = 0; y<80; y++){
			RGBApixel unPixel = parcela.GetPixel(x,y);
			unPixel.Red = 255;
			unPixel.Green = 0;
			unPixel.Blue = 0;
			parcela.SetPixel(x, y, unPixel);	//una parcela roja
		}
	}

	for(int x = 0; x<80;x+=10){
		RGBApixel unPixel;
		unPixel.Red = 0;
		unPixel.Green = 0;
		unPixel.Blue = 0;
		for(int y = 0; y<80;y++){
			parcela.SetPixel(x, y, unPixel);	//lineas verticales
		}
	}

	for(int y = 0; y<80;y+=10){
		RGBApixel unPixel;
		unPixel.Red = 0;
		unPixel.Green = 0;
		unPixel.Blue = 0;
		for(int x = 0; x<80;x++){
			parcela.SetPixel(x, y, unPixel);	//lineas horizontales
		}
	}

	for(int x = 11; x<70;x++){
		for(int y = 11; y<70;y++){
			RGBApixel unPixel = parcela.GetPixel(x,y);
			if((unPixel.Red!=0)||(unPixel.Green!=0)||(unPixel.Blue!=0)){
				unPixel.Red = 0;
				unPixel.Green = 255;
				unPixel.Blue = 0;
				parcela.SetPixel(x, y, unPixel);	//dibujo del portal
			}
		}
	}

	for(int x = 31; x<50;x++){
		for(int y = 21; y<30;y++){
			RGBApixel unPixel = parcela.GetPixel(x,y);
			if((unPixel.Red!=0)||(unPixel.Green!=0)||(unPixel.Blue!=0)){
				unPixel.Red = 0;
				unPixel.Green = 0;
				unPixel.Blue = 255;
				parcela.SetPixel(x, y, unPixel);	//color de celula superior
			}
		}
	}
	for(int x = 21; x<60;x++){
		for(int y = 31; y<50;y++){
			RGBApixel unPixel = parcela.GetPixel(x,y);
			if((unPixel.Red!=0)||(unPixel.Green!=0)||(unPixel.Blue!=0)){
				unPixel.Red = 0;
				unPixel.Green = 0;
				unPixel.Blue = 255;
				parcela.SetPixel(x, y, unPixel);	//color de celula medio
			}
		}
	}
	for(int x = 31; x<50;x++){
		for(int y = 51; y<60;y++){
			RGBApixel unPixel = parcela.GetPixel(x,y);
			if((unPixel.Red!=0)||(unPixel.Green!=0)||(unPixel.Blue!=0)){
				unPixel.Red = 0;
				unPixel.Green = 0;
				unPixel.Blue = 255;
				parcela.SetPixel(x, y, unPixel);	//color de celula inferior
			}
		}
	}
	parcela.WriteToFile("Parcelal.bmp");
	return 0;
}


void operacionesBasicas(){
	// Declare a new bitmap object
	BMP AnImage;  // cuadro blanco de tamaño 1x1 de 24bpp como standard
	// Set size to 640 × 480
	AnImage.SetSize(640,480);
	// Set its color depth to 8-bits
	AnImage.SetBitDepth(8);

	AnImage.WriteToFile("imagen.bmp"); //Guardo el BMP en la carpeta del proyecto

	// Declare another BMP image
	BMP AnotherImage;
	// Read from a file
	AnotherImage.ReadFromFile("Mapa.bmp"); // Se lee el archivo Mapa.bmp

	// Change this pixel to a blue-grayish color
	AnImage(0,0)->Red = 255;
	AnImage(0,0)->Green = 0;
	AnImage(0,0)->Blue = 0;
	AnImage(0,0)->Alpha = 0;

	// show the color of pixel (14,18)
	cout << "(" << (int) AnImage(14,18)->Red
	<< ","
	<< (int) AnImage(14,18)->Green << ","
	<< (int) AnImage(14,18)->Blue << ","
	<< (int) AnImage(14,18)->Alpha << ")" << endl;

	// show the color of pixel (14,18)
	RGBApixel Temp = AnImage.GetPixel(14,18);
	cout << "(" << (int) Temp.Red
	<< ","
	<< (int) Temp.Green << ","
	<< (int) Temp.Blue << ","
	<< (int) Temp.Alpha << ")" << endl;

	// Change this pixel to a blue-grayish color
	Temp.Red = 50; Temp.Green = 50; Temp.Blue = 192; Temp.Alpha = 0;
	AnImage.SetPixel(14,18,Temp);

	AnImage.WriteToFile("imagen.bmp"); //Guardo el BMP en la carpeta del proyecto
}


void modificacionTablaDeColores(){
	BMP SomeImage;
	// Set the bit depth to 8 bpp
	SomeImage.SetBitDepth(8);
	SomeImage.ReadFromFile("imagen.bmp");
	// Get the 40th color
	RGBApixel SomeColor = SomeImage.GetColor(40);
	// Display the color
	cout << (int) SomeColor.Red << ","
	<< (int) SomeColor.Green << ","
	<< (int) SomeColor.Blue << ","
	<< (int) SomeColor.Alpha << endl;

	// Change the 14th color to red
	RGBApixel NewColor;
	NewColor.Red = 255;
	NewColor.Green = 0;
	NewColor.Blue = 0;
	NewColor.Alpha = 0;
	SomeImage.SetColor(14,NewColor);

	// Reset the color table
	SomeImage.CreateStandardColorTable();

	// Create a grayscale color table
	CreateGrayscaleColorTable( SomeImage );

}

void copiaPixelAPixel(){
	BMP Image1;
	BMP Image2;
	Image1.ReadFromFile("Valen.bmp");
	Image2.SetSize(958,1167);
	RGBApixel unColor = Image1.GetPixel(0,0);
	RGBApixel TransparentColor = unColor;  // color que sera transparente en la imagen destino
	for(int pixelX = 600; pixelX<=700; pixelX++){
		for(int pixelY = 0; pixelY<=1166; pixelY++){
			PixelToPixelCopyTransparent(Image1,pixelX,pixelY,Image2,pixelX,pixelY, TransparentColor);
		}
	}
	Image2.WriteToFile("CopiaPixel.bmp");


	Image1.ReadFromFile("Valen.bmp");
	Image2.SetSize(958,1167);
	RangedPixelToPixelCopy(Image1, 600, 700, 0, 1166, Image2, 0, 0); //Copia un rango de pixeles
	Image2.WriteToFile("CopiaPixel.bmp");
}

