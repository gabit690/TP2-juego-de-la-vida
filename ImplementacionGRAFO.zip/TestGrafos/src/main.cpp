/*
 * main.cpp
 *
 *  Created on: 29 nov. 2018
 *      Author: gabit
 */

#include "Grafo.h"
#include <iostream>

int main (){
	Grafo* elGrafo = new Grafo();

	elGrafo->agregarUnVertice("Tablero1");
	elGrafo->agregarUnVertice("Tablero2");
	elGrafo->agregarUnVertice("Tablero3");
	elGrafo->agregarUnVertice("Tablero4");
	elGrafo->agregarUnVertice("Tablero5");
	elGrafo->agregarUnVertice("Tablero6");

	elGrafo->agregarUnaArista("Tablero1", "Tablero2");
	elGrafo->agregarUnaArista("Tablero4", "Tablero1");
	elGrafo->agregarUnaArista("Tablero4", "Tablero2");
	elGrafo->agregarUnaArista("Tablero2", "Tablero4");
	elGrafo->agregarUnaArista("Tablero2", "Tablero6");
	elGrafo->agregarUnaArista("Tablero3", "Tablero6");
	elGrafo->agregarUnaArista("Tablero6", "Tablero3");

	ListaSimple<Arista*>* aristas = elGrafo->obtenerAristas();

	Arista* arista1 = aristas->obtenerElemento(1);
	arista1->aumentarUnidadApeso();

	Arista* arista2 = aristas->obtenerElemento(2);
	arista2->aumentarUnidadApeso();
	arista2->aumentarUnidadApeso();
	arista2->aumentarUnidadApeso();

	Arista* arista3 = aristas->obtenerElemento(3);


	Arista* arista4 = aristas->obtenerElemento(4);
	arista4->aumentarUnidadApeso();
	arista4->aumentarUnidadApeso();

	Arista* arista5 = aristas->obtenerElemento(5);
	arista5->aumentarUnidadApeso();

	Arista* arista6 = aristas->obtenerElemento(6);
	arista6->aumentarUnidadApeso();

	Arista* arista7 = aristas->obtenerElemento(7);
	arista7->aumentarUnidadApeso();
	arista7->aumentarUnidadApeso();
	arista7->aumentarUnidadApeso();
	arista7->aumentarUnidadApeso();
	arista7->aumentarUnidadApeso();
	arista7->aumentarUnidadApeso();

	unsigned int tranferencias = 0;
	Pila<std::string>* camino = elGrafo->obtenerElCaminoMinimo("Tablero1", "Tablero6", tranferencias);

	if(!camino->estaVacia()){
		unsigned int cantidad = camino->contarElementos();
		std::cout << "El camino minimo es:" << std::endl << std::endl;
		for(unsigned int elemento = 1; elemento <= cantidad; elemento++){
			std::string tablero;
			tablero = camino->desapilar();
			std::cout << tablero << std::endl;
		}
		std::cout << "Cantidad de trandferencias: " << tranferencias << std::endl;
	}
	else{
		std::cout << "No hay un camino minimo" << std::endl;
	}


	delete elGrafo;
	delete camino;
	return 0;
}


